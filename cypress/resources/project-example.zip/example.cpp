int square(int num) {
    return num * num;
}

int main () {
   return square(3);
}
